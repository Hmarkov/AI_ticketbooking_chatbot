This folder will contain the received images or other files!
